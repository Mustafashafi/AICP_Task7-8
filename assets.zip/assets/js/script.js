// Wait for DOM content to load before running JavaScript
document.addEventListener('DOMContentLoaded', function() {
    console.log('Document loaded and ready.');

    // Handle form validation
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(event) {
            const email = document.querySelector('input[type="email"]');
            const password = document.querySelector('input[type="password"]');
            const confirmPassword = document.querySelector('input[name="confirm_password"]');

            // Basic form validation
            if (email && !validateEmail(email.value)) {
                alert('Please enter a valid email address.');
                event.preventDefault();
            }
            if (password && confirmPassword && password.value !== confirmPassword.value) {
                alert('Passwords do not match.');
                event.preventDefault();
            }
        });
    }
});

// Email validation function
function validateEmail(email) {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
}

// Mobile navigation toggle
const navMenu = document.querySelector('.nav-menu');
const navToggle = document.querySelector('.nav-toggle');

if (navToggle && navMenu) {
    navToggle.addEventListener('click', function() {
        navMenu.classList.toggle('show');
    });
}
